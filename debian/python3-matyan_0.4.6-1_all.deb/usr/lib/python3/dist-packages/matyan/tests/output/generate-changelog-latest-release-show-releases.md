### 0.2
*2019-11-17*

#### Feature

##### MSFT-1238 Token authentication

- Update authentication docs. [Artur Barseghyan]
- Implement token authentication. [Artur Barseghyan]

##### MSFT-1237 Improve document sharing

- Improve document sharing. Add option to share via GDrive. [Artur Barseghyan]