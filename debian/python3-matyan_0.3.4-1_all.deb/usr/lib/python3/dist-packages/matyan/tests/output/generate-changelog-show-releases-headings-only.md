### 0.2

**Feature**

*MSFT-1238 Token authentication*

*MSFT-1237 Improve document sharing*

### 0.1

**Bugfix**

*MSFT-1236 Prevent duplicate postal codes*

**Deprecation**

*MSFT-1235 Deprecate old api*

**Feature**

*MSFT-1234 Car type suggester*
