### Unreleased

**Bugfix**

*MSFT-1240 LinkedIn authentication failing*

- Update authentication pipeline. [Artur Barseghyan]
- Fix package configuration. [Artur Barseghyan]

**Deprecation**

*MSFT-1239 Deprecate Python2*

- Add initial MyPY setup. [Artur Barseghyan]
- Deprecate Python2. [Artur Barseghyan]
