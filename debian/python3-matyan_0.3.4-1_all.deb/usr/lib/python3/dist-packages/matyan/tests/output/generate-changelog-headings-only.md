**Feature**

*MSFT-1238 Token authentication*

*MSFT-1237 Improve document sharing*

*MSFT-1234 Car type suggester*

**Bugfix**

*MSFT-1236 Prevent duplicate postal codes*

**Deprecation**

*MSFT-1235 Deprecate old api*
