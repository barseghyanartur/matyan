**Feature**

*MSFT-1238 Token Authentication*

*MSFT-1237 Improve Document Sharing*

*MSFT-1234 Car Type Suggester*

**Bugfix**

*MSFT-1236 Prevent Duplicate Postal Codes*

**Deprecation**

*MSFT-1235 Deprecate Old Api*
