### 0.2

**Feature**

*MSFT-1238 Token Authentication*

*MSFT-1237 Improve Document Sharing*

### 0.1

**Bugfix**

*MSFT-1236 Prevent Duplicate Postal Codes*

**Deprecation**

*MSFT-1235 Deprecate Old Api*

**Feature**

*MSFT-1234 Car Type Suggester*
